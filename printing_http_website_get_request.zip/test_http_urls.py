#!/usr/bin/python3
import time
from bs4 import BeautifulSoup
import urllib.request
import re
import os
import subprocess

html_page = urllib.request.urlopen("file:///home/p4/Desktop/test.html") #location of test.html where ever you open the location of zip containing this file.
soup = BeautifulSoup(html_page, "html.parser")
for link in soup.findAll('a', attrs={'href': re.compile("^http://")}):
    print(link.get('href'))
    #os.system('firefox '+link.get('href'))
    #os.system('kill -9 $(ps -x | grep firefox)')
    p = subprocess.Popen(["firefox", link.get('href')])
    time.sleep(30)
    p.kill()
    time.sleep(5)
    #os.system('kill -9 $(ps -x | grep firefox)')
    #os.system('pkill -f firefox')


