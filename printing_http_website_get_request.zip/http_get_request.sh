#!/bin/bash
gnome-terminal -e "bash -c 'sudo python3 printing_get_http_request_content.py;exec $SHELL'"
gnome-terminal -e "bash -c 'python3 test_http_urls.py;exec $SHELL'"
